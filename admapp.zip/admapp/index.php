<?php
$month = date('m');
$day = date('d');
$year = date('Y');
$today = $year . '-' . $month . '-' . $day;
?>
<html>
    <head>
        <title>Admission Application</title>
        <style>
        *{
          box-sizing: border-box;
        }

        body{
        background-color: #f1f1f1;
        }

        #regForm{
        background-color: #ffffff;
        margin: 0px auto;
        padding: 40px;
        width: 55%;
        min-width: 300px;
        }

        table{
        color:white;
        border-radius:0px;
        width: 100%;
        }

        td {
        vertical-align: top;
        font-weight: bold;
        }

        input{
        padding: 7px;
        width: 100%;
        font-size: 15px;
        font-family: Raleway;
        border: 1px solid #aaaaaa;
        }

        input.invalid{
        background-color: #ffdddd;
        }

        select.invalid{
        background-color: #ffdddd;
        }

        .tab{
        display: none;
        }

        select{
        width: 100%;
        padding: 7px;
        margin: 0px;
        }

        button{
          background-color: #04AA6D;
          color: #ffffff;
          border: none;
          padding: 10px 20px;
          font-size: 17px;
          font-family: Raleway;
          cursor: pointer;
        }

        button:hover{
          opacity: 0.8;
        }

        #prevBtn{
          background-color: #bbbbbb;
        }

        /* Make circles that indicate the steps of the form: */
        .step{
          height: 15px;
          width: 15px;
          margin: 0 2px;
          background-color: #bbbbbb;
          border: none;
          border-radius: 50%;
          display: inline-block;
          opacity: 0.5;
        }

        .step.active{
          opacity: 1;
        }

        /* Mark the steps that are finished and valid: */
        .step.finish{
          background-color: #04AA6D;
        }
        </style>

        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
        <script type="text/javascript">
            $(function () {
            $("#ddlNnlty").change(function () {
            if ($(this).val() == "OTHER") {
                $("#txtOther").removeAttr("disabled");
                $("#txtOther").focus();
                }
            else {
                $("#txtOther").attr("disabled", "disabled");
                }
            });
            });

            $(function () {
            $("#ddlReligion").change(function () {
            if ($(this).val() == "OTHER") {
                $("#txtOther1").removeAttr("disabled");
                $("#txtOther1").focus();
                }
            else {
                $("#txtOther1").attr("disabled", "disabled");
                }
            });
            });

            $(function () {
            $("#ddlDisability").change(function () {
            if ($(this).val() == "YES") {
                $("#txtYes").removeAttr("disabled");
                $("#txtYes").focus();
                }
            else {
                $("#txtYes").attr("disabled", "disabled");
                }
            });
            });

            $(function () {
            $("#ddlSscbos").change(function () {
            if ($(this).val() == "OTHER") {
                $("#txtOtherSsc").removeAttr("disabled");
                $("#txtOtherSsc").focus();
                }
            else {
                $("#txtOtherSsc").attr("disabled", "disabled");
                }
            });
            });

            $(function () {
            $("#ddlHscbos").change(function () {
            if ($(this).val() == "OTHER") {
                $("#txtOtherHsc").removeAttr("disabled");
                $("#txtOtherHsc").focus();
                }
            else {
                $("#txtOtherHsc").attr("disabled", "disabled");
                }
            });
            });

            $(function () {
            $("#ddlSlang").change(function () {
            if ($(this).val() == "OTHER") {
                $("#txtSlanguage").removeAttr("disabled");
                $("#txtSlanguage").focus();
                }
            else {
                $("#txtSlanguage").attr("disabled", "disabled");
                }
            });
            });

            $(function () {
            $("#ddlSuggest").change(function () {
            if ($(this).val() == "REFERER") {
                $("#txtRname").removeAttr("disabled");
                $("#txtRname").focus();
                }
            else {
                $("#txtRname").attr("disabled", "disabled");
                }
            });
            });

            $(function () {
            $("#ddlSuggest").change(function () {
            if ($(this).val() == "REFERER") {
                $("#txtRrelation").removeAttr("disabled");
                $("#txtRrelation").focus();
                }
            else {
                $("#txtRrelation").attr("disabled", "disabled");
                }
            });
            });

            $(function () {
            $("#ddlSuggest").change(function () {
            if ($(this).val() == "REFERER") {
                $("#txtRmobile").removeAttr("disabled");
                $("#txtRmobile").focus();
                }
            else {
                $("#txtRmobile").attr("disabled", "disabled");
                }
            });
            });

            $(function () {
            $("#ddlConcession").change(function () {
            if ($(this).val() == 1) {
                $("#txtConcession").removeAttr("disabled");
                $("#txtConcession").focus();
                }
            else {
                $("#txtConcession").attr("disabled", "disabled");
                }
            });
            });
            $(function() {
                $('input').keyup(function() {
                    if(this.getAttribute('type') === 'text'){
                        this.value = this.value.toLocaleUpperCase();
                    }

                });
            });
        </script>
    </head>
<br><br>

<form id="regForm" action="pdf.php" method="POST">

<div class="tab">
    <table border="0" bgcolor="333366" align="center" cellspacing="20">
        <tr><td colspan="2" align="center"><u><h2>ADMISSION DETAILS</h2></u></td></tr>
        <tr>
        <td>Seat Type</td>
        <td><select name="seattype">
            <option value="CONVENOR">CONVENOR</option></option>
            <option value="MANAGEMENT">MANAGEMENT</option>
            </select>
        </td>
        </tr>

        <tr>
        <td>Date of Joining</td>
        <td><input type="date" name="doj" value="<?php echo $today; ?>" class="form-control"></td>
        </tr>

        <tr>
        <td>Student Full Name</td>
        <td><input type="text" placeholder="As Per SSC/SSLC" name="sname"></td>
        </tr>

        <tr>
        <td>Student Aadhaar No.</td>
        <td><input type="text" placeholder="Enter 12 Digit Aadhaar No." maxlength="12" pattern="\d{12}" size="12" name="saadhaar"></td>
        </tr>

        <tr>
        <td>Date of Birth</td>
        <td><input type="date" name="dob" ></td>
        </tr>

        <tr>
        <td>Nationality</td>
        <td><select id="ddlNnlty" name="nationality">
            <option value="INDIAN">INDIAN</option></option>
            <option value="OTHER">OTHER</option>
            </select>
            <br><input type="text" id="txtOther" placeholder="Enter the Nationality" name="onationality" disabled="disabled" /></br>
        </td>
        </tr>

        <tr>
        <td>Religion</td>
        <td><select id="ddlReligion" name="religion" >
            <option value="" disabled selected>SELECT</option></option>
            <option value="HINDU">HINDU</option>
            <option value="MUSLIM">MUSLIM</option>
            <option value="CHRISTIAN">CHRISTIAN</option>
            <option value="OTHER">OTHER</option>
            </select>
            <br><input type="text" id="txtOther1" placeholder="Enter the Religion" name="oreligion" disabled="disabled" /></br>
        </td>
        </tr>

        <tr>
        <td>Category</td>
        <td><select name="category">
            <option value="" disabled selected>SELECT</option></option>
            <option value="BC-A">BC-A</option>
            <option value="BC-B">BC-B</option>
            <option value="BC-C">BC-C</option>
            <option value="BC-D">BC-D</option>
            <option value="BC-E">BC-E</option>
            <option value="GEN">GEN</option>
            <option value="OBC">OBC</option>
            <option value="OC">OC</option>
            <option value="SC">SC</option>
            <option value="ST">ST</option>
            </select>
        </td>
        </tr>

        <tr>
        <td>Caste</td>
        <td><input type="text" placeholder="KAPU/CHOWDARY/MUSLIM/CHRISTIAN etc.." name="caste"></td>
        </tr>

        <tr>
        <td>Any Disability(PwD)</td>
        <td><select id="ddlDisability" name="disability">
            <option value="NO">NO</option></option>
            <option value="YES">YES</option>
            </select>
            <br><input type="text" id="txtYes" placeholder="OH/HH/VH etc..." name="pwdtype" disabled="disabled" /></br>
        </td>
        </tr>

        <tr>
        <td>Scholarship Eligibility</td>
        <td><select name="scholarship">
            <option value="" disabled selected>SELECT</option></option>
            <option value="YES">YES</option></option>
            <option value="NO">NO</option>
            </select>
        </td>
        </tr>

        <tr>
        <td>Student Mobile No.</td>
        <td><input type="text" placeholder="Enter 10 Digit Mobile No." maxlength="10" size="10" pattern="\d{10}"name="smobile"></td>
        </tr>
    </table>
</div>

<div class="tab">
    <table border="0" bgcolor="333366" align="center" cellspacing="20">
        <tr><td colspan="2" align="center"><u><h2>ACADEMIC INFORMATION</h2></u></td></tr>
        <tr>
        <td>10TH CGPA/PERCENTAGE</td>
        <td><input type="text" placeholder="SSC/SSLC CGPA" name="ssccgpa" autofocus></td>
        </tr>

        <tr>
        <td>10TH BOARD OF STUDY</td>
        <td><select id="ddlSscbos" name="sscbos">
            <option value="" disabled selected>SELECT</option></option>
            <option value="SSC">SSC</option>
            <option value="SSLC">SSLC</option>
            <option value="CBSE">CBSE</option>
            <option value="ICSE">ICSE</option>
            <option value="OTHER">OTHER</option>
            </select>
            <br><input type="text" id="txtOtherSsc" placeholder="Enter your Board of Study" name="osscbos" disabled="disabled" /></br>
        </td>
        </tr>

        <tr>
        <td>10TH SCHOOL STUDIED</td>
        <td><input type="text" placeholder="SSC/SSLC School Name" name="schname"></td>
        </tr>

        <tr>
        <td>10TH YEAR OF PASSING</td>
        <td><select name="sscyop">
            <option value="" disabled selected>SELECT</option></option>
            <option value="<?php echo $year-12?>"><?php echo $year-12?></option>
            <option value="<?php echo $year-11?>"><?php echo $year-11?></option>
            <option value="<?php echo $year-10?>"><?php echo $year-10?></option>
            <option value="<?php echo $year-9?>"><?php echo $year-9?></option>
            <option value="<?php echo $year-8?>"><?php echo $year-8?></option>
            <option value="<?php echo $year-7?>"><?php echo $year-7?></option>
            <option value="<?php echo $year-6?>"><?php echo $year-6?></option>
            <option value="<?php echo $year-5?>"><?php echo $year-5?></option>
            <option value="<?php echo $year-4?>"><?php echo $year-4?></option>
            <option value="<?php echo $year-3?>"><?php echo $year-3?></option>
            <option value="<?php echo $year-2?>"><?php echo $year-2?></option>
            </select>
        </td>
        </tr>

        <tr>
        <td>12TH CGPA/PERCENTAGE</td>
        <td><input type="text" placeholder="12TH/HSC CGPA" name="hsccgpa"></td>
        </tr>

        <tr>
        <td>12TH BOARD OF STUDY</td>
        <td><select id="ddlHscbos" name="hscbos">
            <option value="" disabled selected>SELECT</option></option>
            <option value="BIEAP">BIEAP</option>
            <option value="CBSE">CBSE</option>
            <option value="APOSS">APOSS</option>
            <option value="OTHER">OTHER</option>
            </select>
            <br><input type="text" id="txtOtherHsc" placeholder="Enter 12th Board of Study" name="ohscbos" disabled="disabled" /></br>
        </td>
        </tr>

        <tr>
        <td>12TH COLLEGE STUDIED</td>
        <td><input type="text" placeholder="12TH/HSC College Name" name="clgname"></td>
        </tr>

        <tr>
        <td>12TH YEAR OF PASSING</td>
        <td><select name="hscyop">
            <option value="" disabled selected>SELECT</option></option>
            <option value="<?php echo $year-10?>"><?php echo $year-10?></option>
            <option value="<?php echo $year-9?>"><?php echo $year-9?></option>
            <option value="<?php echo $year-8?>"><?php echo $year-8?></option>
            <option value="<?php echo $year-7?>"><?php echo $year-7?></option>
            <option value="<?php echo $year-6?>"><?php echo $year-6?></option>
            <option value="<?php echo $year-5?>"><?php echo $year-5?></option>
            <option value="<?php echo $year-4?>"><?php echo $year-4?></option>
            <option value="<?php echo $year-3?>"><?php echo $year-3?></option>
            <option value="<?php echo $year-2?>"><?php echo $year-2?></option>
            <option value="<?php echo $year-1?>"><?php echo $year-1?></option>
            <option value="<?php echo $year?>"><?php echo $year?></option>
            </select>
        </td>
        </tr>
    </table>
</div>

<div class="tab">
    <table border="0" bgcolor="333366" align="center" cellspacing="20">
        <tr><td colspan="2" align="center"><u><h2>PARENT INFORMATION</h2></u></td></tr>
        <tr>
        <td>Father Name</td>
        <td><input type="text" placeholder="As Per SSC/SSLC" name="fname" autofocus></td>
        </tr>

        <tr>
        <td>Father Occupation</td>
        <td><input type="text" placeholder="Daily Labour/Business etc..." name="foccupation"></td>
        </tr>

        <tr>
        <td>Father Aadhaar No.</td>
        <td><input type="text" placeholder="Enter 12 Digit Aadhaar No." maxlength="12" pattern="\d{12}"name="faadhaar"></td>
        </tr>

        <tr>
        <td>Mother Name</td>
        <td><input type="text" placeholder="As Per SSC/SSLC" name="mname"></td>
        </tr>

        <tr>
        <td>Mother Occupation</td>
        <td><input type="text" placeholder="Daily Labour/Business etc..." name="moccupation"></td>
        </tr>

        <tr>
        <td>Mother Aadhaar No.</td>
        <td><input type="text" placeholder="Enter 12 Digit Aadhaar No." maxlength="12" pattern="\d{12}"name="maadhaar"></td>
        </tr>

        <tr>
        <td>Parent Mobile No.</td>
        <td><input type="text" placeholder="Enter 10 Digit Mobile No." maxlength="10" size="10" pattern="\d{10}" name="pmobile"></td>
        </tr>
    </table>
</div>

<div class="tab">
    <table border="0" bgcolor="333366" align="center" cellspacing="20">
        <tr><td colspan="2" align="center"><u><h2>ADDRESS INFORMATION</h2></u></td></tr>
        <tr>
        <td>Door No</td>
        <td><input type="text" placeholder="House/Door Number" name="dno" autofocus></td>
        </tr>

        <tr>
        <td>Street Name</td>
        <td><input type="text" placeholder="Street Name" name="street"></td>
        </tr>

        <tr>
        <td>Village and Mandal</td>
        <td><input type="text" placeholder="Village and Mandal" name="village"></td>
        </tr>

        <tr>
        <td>District</td>
        <td><input type="text" placeholder="District" name="district"></td>
        </tr>

        <tr>
        <td>State</td>
        <td><input type="text" placeholder="State" name="state"></td>
        </tr>

        <tr>
        <td>Pincode</td>
        <td><input type="text" placeholder="Enter Pincode" maxlength="6" size="6" pattern="\d{6}"name="pincode"></td>
        </tr>
    </table>
</div>

<div class="tab">
    <table border="0" bgcolor="333366" align="center" cellspacing="20">
        <tr><td colspan="2" align="center"><u><h2>COURSE INFORMATION</h2></u></td></tr>
        <tr>
            <td>Course</td>
            <td><select name="course">
                <option value="" disabled selected>SELECT</option></option>
                <option value="BBA(BACHELOR OF BUSINESS ADMINISTRATION)">BBA</option>
                <option value="BBA(DIGITAL MARKETING)">BBA(DM)</option>
                <option value="B.Com.(COMPUTER APPLICATIONS)">B.Com.(CA)</option>
                <option value="B.Sc.(MPC)">B.Sc.(MPC)</option>
                <option value="B.Sc.(MPCs)">B.Sc.(MPCs)</option>
                <option value="B.Sc.(MSCs)">B.Sc.(MSCs)</option>
                <option value="B.Sc.(ANIMATION)">B.Sc.(ANI)</option>
                <option value="BCA(BACHELOR OF COMPUTER APPLICATION)">BCA</option>
                <option value="B.Sc.(FORENSIC SCIENCE)">B.Sc.(FS)</option>
                </select>
            </td>
        </tr>

        <tr>
            <td>Preferred Second Language</td>
            <td><select id="ddlSlang" name="slanguage">
                <option value="" disabled selected>SELECT</option></option>
                <option value="TELUGU">TELUGU</option>
                <option value="SANSKRIT">SANSKRIT</option>
                <option value="HINDI">HINDI</option>
                <option value="OTHER">OTHER</option>
                </select>
                <br><input type="text" id="txtSlanguage" placeholder="Enter Second Language" name="oslanguage" disabled="disabled" /></br>
            </td>
        </tr>
        <tr>
            <td>Any Concession Given:</td>
            <td><select id="ddlConcession" name="concession">
                <option value="0">NO</option>
                <option value="1">YES</option>
                </select>
                <br><input type="number" id="txtConcession" placeholder="Enter the Concession Amount" name="oconcession" disabled="disabled" /></br>
            </td>
        </tr>
    </table>
</div>

<div class="tab">
    <table border="0" bgcolor="333366" align="center" cellspacing="20">
        <tr><td colspan="2" align="center"><u><h2>CERTIFICATE INFORMATION</h2></u></td></tr>
        <tr>
            <td>ORIGINAL CERTIFICATES SUBMITTED</td>
            <td>
                <table border="0" bgcolor="333366" align="center" cellspacing="10">
                    <tr><td><input type="checkbox" id="oc1" name="oc1" value="10TH MARKS MEMO" autofocus></td><td>10TH/EQUIVALENT MARKS MEMO</td></tr>
                    <tr><td><input type="checkbox" id="oc2" name="oc2" value="12TH MARKS MEMO"></td><td>12TH/EQUIVALENT MARKS MEMO</td></tr>
                    <tr><td><input type="checkbox" id="oc3" name="oc3" value="TRANSFER CERTIFICATE"></td><td>TRANSFER CERTIFICATE</td></tr>
                    <tr><td><input type="checkbox" id="oc4" name="oc4" value="MIGRATION CERTIFICATE"></td><td>MIGRATION CERTIFICATE</td></tr>
                    <tr><td><input type="checkbox" id="oc5" name="oc5" value="STUDY AND CONDUCT"></td><td>STUDY AND CONDUCT</td></tr>
                    <tr><td><input type="checkbox" id="oc6" name="oc6" value="PASSPORT PHOTOS(6 No.)"></td><td>PASSPORT PHOTOS(6 No.)</td></tr>
                </table>
            </td>
        </tr>

        <tr>
            <td>XEROX CERTIFICATES SUBMITTED</td>
            <td>
                <table border="0" bgcolor="333366" align="center" cellspacing="10">
                    <tr><td><input type="checkbox" id="xc1" name="xc1" value="CASTE/EWS CERIFICATE"></td><td>CASTE/EWS CERIFICATE(IF APPLICABLE)</td></tr>
                    <tr><td><input type="checkbox" id="xc2" name="xc2" value="INCOME CERTIFICATE"></td><td>INCOME CERTIFICATE (IF APPLICABLE)</td></tr>
                    <tr><td><input type="checkbox" id="xc3" name="xc3" value="PH CERTIFICATE"></td><td>PH CERTIFICATE (IF APPLICABLE)</td></tr>
                    <tr><td><input type="checkbox" id="xc4" name="xc4" value="RATION CARD"></td><td>RATION CARD (IF APPLICABLE)</td></tr>
                    <tr><td><input type="checkbox" id="xc5" name="xc5" value="STUDENT BANK PASSBOOK"></td><td>STUDENT BANK PASSBOOK FRONT PAGE</td></tr>
                    <tr><td><input type="checkbox" id="xc6" name="xc6" value="MOTHER BANK PASSBOOK"></td><td>MOTHER BANK PASSBOOK FRONT PAGE</td></tr>
                    <tr><td><input type="checkbox" id="xc7" name="xc7" value="STUDENT AADHAAR CARD"></td><td>STUDENT AADHAAR CARD</td></tr>
                    <tr><td><input type="checkbox" id="xc8" name="xc8" value="FATHER AADHAAR CARD"></td><td>FATHER AADHAAR CARD</td></tr>
                    <tr><td><input type="checkbox" id="xc9" name="xc9" value="MOTHER AADHAAR CARD"></td><td>MOTHER AADHAAR CARD</td></tr>
                </table>
            </td>
        </tr>
    </table>
</div>

<div class="tab">
    <table border="0" bgcolor="333366" align="center" cellspacing="20">
        <tr><td colspan="2" align="center"><u><h2>REFERENCE INFORMATION</h2></u></td></tr>
        <tr>
        <td>Who suggested you the College?</td>
        <td><select id="ddlSuggest" name="suggest" autofocus>
            <option value="SELF">SELF</option></option>
            <option value="REFERER">REFERER</option>
            </select>
            <br><input type="text" id="txtRname" placeholder="Name of the Referer" name="rname" disabled="disabled" />
            <br><input type="text" id="txtRrelation" placeholder="Enter PIN(If Student)/PRO(If Outsider)" name="rrelation" disabled="disabled" />
            <br><input type="text" id="txtRmobile" placeholder="Enter 10 Digit Mobile No." maxlength="10" pattern="\d{10}" name="rmobile" disabled="disabled" />
        </td>
        </tr>
    </table>
</div>

<div style="overflow:auto;">
    <div style="float:right;">
        <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
        <button type="button" id="nextBtn" onclick="nextPrev(1)">Next</button>
    </div>
</div>

<!-- Circles which indicates the steps of the form: -->
<div style="text-align:center;margin-top:40px;">
    <span class="step"></span>
    <span class="step"></span>
    <span class="step"></span>
    <span class="step"></span>
    <span class="step"></span>
    <span class="step"></span>
    <span class="step"></span>
</div>


</form>

<script>
    var currentTab = 0; // Current tab is set to be the first tab (0)
    showTab(currentTab); // Display the current tab

    function showTab(n) {
      // This function will display the specified tab of the form...
      var x = document.getElementsByClassName("tab");
      x[n].style.display = "block";
      //... and fix the Previous/Next buttons:
      if (n == 0) {
        document.getElementById("prevBtn").style.display = "none";
      } else {
        document.getElementById("prevBtn").style.display = "inline";
      }
      if (n == (x.length - 1)) {
        document.getElementById("nextBtn").innerHTML = "Submit";
        //document.getElementById("nextBtn").style.display = "none";
      } else {
        document.getElementById("nextBtn").innerHTML = "Next";
      }
      //... and run a function that will display the correct step indicator:
      fixStepIndicator(n)
    }

    function nextPrev(n) {
      // This function will figure out which tab to display
      var x = document.getElementsByClassName("tab");
      // Exit the function if any field in the current tab is invalid:
      if (n == 1 && !validateForm()) return false;
      // Hide the current tab:
      x[currentTab].style.display = "none";
      // Increase or decrease the current tab by 1:
      currentTab = currentTab + n;
      // if you have reached the end of the form...
      if (currentTab >= x.length) {
        // ... the form gets submitted:
        document.getElementById("regForm").submit();
        return false;
      }
      // Otherwise, display the correct tab:
      showTab(currentTab);
    }

    function validateForm() {
      // This function deals with validation of the form fields
      var x, y, z, i, valid = true;
      x = document.getElementsByClassName("tab");
      y = x[currentTab].getElementsByTagName("input");
      z = x[currentTab].getElementsByTagName("select");
      // A loop that checks every input field in the current tab:

      for (i = 0; i < y.length; i++) {
        // If a field is empty...
        if (y[i].value == "") {
            if(y[i].disabled){
                valid = true;
            }
            else{
              // add an "invalid" class to the field:
              y[i].className += " invalid";
              // and set the current valid status to false
              valid = false;
            }

        }
      }

      for (i = 0; i < z.length; i++) {
        // If a field is empty...
        if (z[i].value == "") {
          // add an "invalid" class to the field:
          z[i].className += " invalid";
          // and set the current valid status to false
          valid = false;
        }
      }

      // If the valid status is true, mark the step as finished and valid:
      if (valid) {
        document.getElementsByClassName("step")[currentTab].className += " finish";
      }
      return valid; // return the valid status
    }

    function fixStepIndicator(n) {
      // This function removes the "active" class of all steps...
      var i, x = document.getElementsByClassName("step");
      for (i = 0; i < x.length; i++) {
        x[i].className = x[i].className.replace(" active", "");
      }
      //... and adds the "active" class on the current step:
      x[n].className += " active";
    }
</script>

</body>
</html>
