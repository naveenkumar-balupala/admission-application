<?php
    require("fpdf/fpdf.php");
    require_once("config.php");

	$pdf = new FPDF('P','mm','A4');
	$pdf->SetCreator("Naveen Kumar Balupala, 8332033130");

    function numberTowords($num)
    {
    $ones = array(
    0 =>"ZERO",
    1 => "ONE",
    2 => "TWO",
    3 => "THREE",
    4 => "FOUR",
    5 => "FIVE",
    6 => "SIX",
    7 => "SEVEN",
    8 => "EIGHT",
    9 => "NINE",
    10 => "TEN",
    11 => "ELEVEN",
    12 => "TWELVE",
    13 => "THIRTEEN",
    14 => "FOURTEEN",
    15 => "FIFTEEN",
    16 => "SIXTEEN",
    17 => "SEVENTEEN",
    18 => "EIGHTEEN",
    19 => "NINETEEN",
    "014" => "FOURTEEN"
    );
    $tens = array(
    0 => "ZERO",
    1 => "TEN",
    2 => "TWENTY",
    3 => "THIRTY",
    4 => "FORTY",
    5 => "FIFTY",
    6 => "SIXTY",
    7 => "SEVENTY",
    8 => "EIGHTY",
    9 => "NINETY"
    );
    $hundreds = array(
    "HUNDRED",
    "THOUSAND",
    "MILLION",
    "BILLION",
    "TRILLION",
    "QUARDRILLION"
    ); /*limit t quadrillion */
    $num = number_format($num,2,".",",");
    $num_arr = explode(".",$num);
    $wholenum = $num_arr[0];
    $decnum = $num_arr[1];
    $whole_arr = array_reverse(explode(",",$wholenum));
    krsort($whole_arr,1);
    $rettxt = "";
    foreach($whole_arr as $key => $i){

    while(substr($i,0,1)=="0")
            $i=substr($i,1,5);
    if($i < 20){
    /* echo "getting:".$i; */
    //$rettxt .= $ones[$i];
    }elseif($i < 100){
    if(substr($i,0,1)!="0")  $rettxt .= $tens[substr($i,0,1)];
    if(substr($i,1,1)!="0") $rettxt .= " ".$ones[substr($i,1,1)];
    }else{
    if(substr($i,0,1)!="0") $rettxt .= $ones[substr($i,0,1)]." ".$hundreds[0];
    if(substr($i,1,1)!="0") $rettxt .= " ".$tens[substr($i,1,1)];
    if(substr($i,2,1)!="0") $rettxt .= " ".$ones[substr($i,2,1)];
    }
    if($key > 0){
    $rettxt .= " ".$hundreds[$key]." ";
    }
    }
    if($decnum > 0){
    $rettxt .= " and ";
    if($decnum < 20){
    $rettxt .= $ones[$decnum];
    }elseif($decnum < 100){
    $rettxt .= $tens[substr($decnum,0,1)];
    $rettxt .= " ".$ones[substr($decnum,1,1)];
    }
    }
    return $rettxt;
    }
//if(!empty($_POST['submit']))
{
	$seattype = $_POST['seattype'];//1
	//$admno = $_POST['admno'];//2
	$doj = date('d-m-Y',strtotime($_POST['doj']));//3
	$sname = $_POST['sname'];//4
	$saadhaar = $_POST['saadhaar'];//5
	$dob = date('d-m-Y',strtotime($_POST['dob']));//6
	$nationality = $_POST['nationality'];
	if(!empty($_POST['onationality'])){$nationality = $_POST['onationality'];}//7
	$religion = $_POST['religion'];
	if(!empty($_POST['oreligion'])){$religion = $_POST['oreligion'];}//8
	$category = $_POST['category'];//9
	$caste = $_POST['caste'];//10
	$disability = $_POST['disability'];
	if(!empty($_POST['pwdtype'])){$disability = $_POST['pwdtype'];}//11
	$scholarship = $_POST['scholarship'];//12
	$smobile = $_POST['smobile'];//13
	$ssccgpa = $_POST['ssccgpa'];//14
	$sscbos = $_POST['sscbos'];
	if(!empty($_POST['osscbos'])){$sscbos = $_POST['osscbos'];}//15
	$schname = $_POST['schname'];//16
	$sscyop = $_POST['sscyop'];//17
	$hsccgpa = $_POST['hsccgpa'];//18
	$hscbos = $_POST['hscbos'];
	if(!empty($_POST['ohscbos'])){$hscbos = $_POST['ohscbos'];}//19
	$clgname = $_POST['clgname'];//20
	$hscyop = $_POST['hscyop'];//21
	$fname = $_POST['fname'];//22
	$foccupation = $_POST['foccupation'];//23
	$faadhaar = $_POST['faadhaar'];//24
	$mname = $_POST['mname'];//25
	$moccupation = $_POST['moccupation'];//26
	$maadhaar = $_POST['maadhaar'];//27
	$pmobile = $_POST['pmobile'];//28
	$dno = $_POST['dno'];//29
	$street = $_POST['street'];//30
	$village = $_POST['village'];//31
	$district = $_POST['district'];//32
	$state = $_POST['state'];//33
	$pincode = $_POST['pincode'];//34
	$course = $_POST['course'];//35
	$y = date("Y");
	$slanguage = $_POST['slanguage'];
	if(!empty($_POST['oslanguage'])){$slanguage = $_POST['oslanguage'];}//36
	if($course == "BBA(BACHELOR OF BUSINESS ADMINISTRATION)" || $course == "BBA(DIGITAL MARKETING)"){
        $tf = 18500;//37
        $af = 2700;//38
        $lf = 0;//39
        $iif = 5000;//40
        $pf = 11800;//41
	}
	if($course == "B.Com.(COMPUTER APPLICATIONS)"){
        $tf = 15000;
        $af = 2700;
        $lf = 3000;
        $iif = 3000;
        $pf = 6300;
	}
	if($course == "B.Sc.(MPC)"){
        $tf = 15000;
        $af = 2700;
        $lf = 6000;
        $iif = 0;
        $pf = 6300;
	}
	if($course == "B.Sc.(MPCs)" || $course == "B.Sc.(MSCs)"){
        $tf = 16000;
        $af = 2700;
        $lf = 6000;
        $iif = 0;
        $pf = 13300;
	}
	if($course == "B.Sc.(ANIMATION)"){
        $tf = 16000;
        $af = 2700;
        $lf = 9000;
        $iif = 0;
        $pf = 12300;
	}
	if($course == "B.Sc.(FORENSIC SCIENCE)"){
        $tf = 16000;
        $af = 2700;
        $lf = 9000;
        $iif = 0;
        $pf = 15300;
	}
	if($course == "BCA(BACHELOR OF COMPUTER APPLICATION)"){
        $tf = 18500;
        $af = 2700;
        $lf = 9000;
        $iif = 0;
        $pf = 12800;
	}
	$concession = $_POST['concession'];//42
	if(!empty($_POST['oconcession'])){$concession = $_POST['oconcession'];}
	$totf = $tf + $af + $lf + $iif + $pf - $concession;//43
	$num = $totf;

	$originals = "";//44
	if(!empty($_POST['oc1'])){$oc1 = $_POST['oc1']; $originals .= $oc1; if(!empty($originals)){$originals .= ", ";}}
	if(!empty($_POST['oc2'])){$oc2 = $_POST['oc2']; $originals .= $oc2; if(!empty($originals)){$originals .= ", ";}}
	if(!empty($_POST['oc3'])){$oc3 = $_POST['oc3']; $originals .= $oc3; if(!empty($originals)){$originals .= ", ";}}
	if(!empty($_POST['oc4'])){$oc4 = $_POST['oc4']; $originals .= $oc4; if(!empty($originals)){$originals .= ", ";}}
	if(!empty($_POST['oc5'])){$oc5 = $_POST['oc5']; $originals .= $oc5; if(!empty($originals)){$originals .= ", ";}}
	if(!empty($_POST['oc6'])){$oc6 = $_POST['oc6']; $originals .= $oc6;}

	$xerox = "";//45
    if(!empty($_POST['xc1'])){$xc1 = $_POST['xc1']; $xerox .= $xc1; if(!empty($xerox)){$xerox .= ", ";}}
    if(!empty($_POST['xc2'])){$xc2 = $_POST['xc2']; $xerox .= $xc2; if(!empty($xerox)){$xerox .= ", ";}}
    if(!empty($_POST['xc3'])){$xc3 = $_POST['xc3']; $xerox .= $xc3; if(!empty($xerox)){$xerox .= ", ";}}
    if(!empty($_POST['xc4'])){$xc4 = $_POST['xc4']; $xerox .= $xc4; if(!empty($xerox)){$xerox .= ", ";}}
    if(!empty($_POST['xc5'])){$xc5 = $_POST['xc5']; $xerox .= $xc5; if(!empty($xerox)){$xerox .= ", ";}}
    if(!empty($_POST['xc6'])){$xc6 = $_POST['xc6']; $xerox .= $xc6; if(!empty($xerox)){$xerox .= ", ";}}
    if(!empty($_POST['xc7'])){$xc7 = $_POST['xc7']; $xerox .= $xc7; if(!empty($xerox)){$xerox .= ", ";}}
    if(!empty($_POST['xc8'])){$xc8 = $_POST['xc8']; $xerox .= $xc8; if(!empty($xerox)){$xerox .= ", ";}}
    if(!empty($_POST['xc9'])){$xc9 = $_POST['xc9']; $xerox .= $xc9;}
	$suggest = $_POST['suggest'];//46
	if(!empty($_POST['rname'])){
        $rname = $_POST['rname'];
        $rrelation = $_POST['rrelation'];
        $rmobile = $_POST['rmobile'];
        $suggest = $rname." - ".$rrelation." - ".$rmobile;
        }

    $con = mysqli_connect("localhost","root","","admapp");
    $sql1 = "SELECT * from student_info";
    if ($result1 = mysqli_query($con, $sql1)) {
        // Return the number of rows in result set
        $rowcount = mysqli_num_rows( $result1);
    }
    mysqli_close($con);
    $admno = "GDC".(22001+$rowcount);//2
    $pdf->SetTitle($admno."_".$sname);
    $sql = "INSERT INTO student_info(seattype, admno, doj, sname, saadhaar, dob, nationality, religion, category, caste, disability, scholarship, smobile, ssccgpa, sscbos, schname, sscyop, hsccgpa, hscbos, clgname, hscyop, fname, foccupation, faadhaar, mname, moccupation, maadhaar, pmobile, dno, street, village, district, state, pincode, course, slanguage, tf, af, lf, iif, pf, concession, totf, originals, xerox, suggest) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    $stmtinsert = $db->prepare($sql);
    $result = $stmtinsert->execute([$seattype, $admno, $doj, $sname, $saadhaar, $dob, $nationality, $religion, $category, $caste, $disability, $scholarship, $smobile, $ssccgpa, $sscbos, $schname, $sscyop, $hsccgpa, $hscbos, $clgname, $hscyop, $fname, $foccupation, $faadhaar, $mname, $moccupation, $maadhaar, $pmobile, $dno, $street, $village, $district, $state, $pincode, $course, $slanguage, $tf, $af, $lf, $iif, $pf, $concession, $totf, $originals, $xerox, $suggest]);

	//First Page
	$pdf->AddPage();

	$pdf->SetXY(0, 0);
    $pdf->Image('images/header.jpg');
    $pdf->SetXY(10, 10);
    $pdf->SetFont('Arial','B',12);
    $pdf->Cell(12,8,"PIN :",0,0);
    $pdf->Cell(6,8,substr($y,-2,1),1,0,'C');
    $pdf->Cell(6,8,substr($y,-1),1,0,'C');
    $pdf->Cell(6,8,"1",1,0,'C');
    $pdf->Cell(6,8,"4",1,0,'C');
    $pdf->Cell(6,8,"8",1,0,'C');
    $pdf->Cell(6,8,"",1,0);
    $pdf->Cell(6,8,"",1,0);
    $pdf->Cell(6,8,"",1,0);
    $pdf->Cell(6,8,"",1,0);
    $pdf->Cell(6,8,"",1,0);
    $pdf->Cell(0,8,$seattype,0,1,'R');

    $pdf->SetXY(10, 50);
    $pdf->SetFont('Arial','',12);

    $pdf->Cell(70,10, "Admission No",0,0);
    $pdf->Cell(70,10, ": ".$admno,0,0);
    $pdf->Cell(0,10, "Date : ".$doj,0,1);
    $pdf->Cell(70,10, "Student Name (As Per SSC)",0,0);
    $cellWidth = 110;
    $tempFontSize = 12;
    while($pdf->GetStringWidth($sname)>$cellWidth){
        $pdf->SetFontSize($tempFontSize -= 0.1);
    }
    $pdf->Cell(0,10, ": ".$sname,0,1);
    $pdf->SetFont('Arial','',12);
    $pdf->Cell(70,10, "Name of the Father / Guardian",0,0);
    $tempFontSize = 12;
    while($pdf->GetStringWidth($fname)>$cellWidth){
        $pdf->SetFontSize($tempFontSize -= 0.1);
    }
    $pdf->Cell(0,10, ": ".$fname,0,1);
    $pdf->SetFont('Arial','',12);
    $pdf->Cell(70,10, "Name of the Mother",0,0);
    $tempFontSize = 12;
    while($pdf->GetStringWidth($mname)>$cellWidth){
        $pdf->SetFontSize($tempFontSize -= 0.1);
    }
    $pdf->Cell(0,10, ": ".$mname,0,1);
    $pdf->SetFont('Arial','',12);
    $pdf->Cell(70,10, "Date of Birth (dd/mm/yyyy)",0,0);
    $pdf->Cell(0,10, ": ".$dob,0,1);
    $pdf->SetFont('Arial','BU',12);
    $pdf->Cell(0,10, "COURSE DETAILS:",0,1);
    $pdf->SetFont('Arial','',12);
    $pdf->Cell(36,10, "Course Joined",0,0);
    $pdf->Cell(105,10, ": ".$course,0,0);
    $pdf->Cell(25,10, "Nationality",0,0);
    $pdf->Cell(0,10, ": ".$nationality,0,1);
    $pdf->Cell(36,10, "Second Language",0,0);
    $pdf->Cell(105,10, ": ".$slanguage,0,0);
    $pdf->Cell(25,10, "Religion",0,0);
    $pdf->Cell(0,10, ": ".$religion,0,1);
    $pdf->Cell(36,10, "Caste",0,0);
    $tempFontSize = 12;
    while($pdf->GetStringWidth($caste)>100){
        $pdf->SetFontSize($tempFontSize -= 0.1);
    }
    $pdf->Cell(105,10, ": ".$caste,0,0);
    $pdf->SetFont('Arial','',12);
    $pdf->Cell(25,10, "Category",0,0);
    $pdf->Cell(0,10, ": ".$category,0,1);
    $pdf->Cell(70,10, "If Physically Handicap (Specify)",0,0);
    $pdf->Cell(0,10, ": ".$disability,0,1);
    $pdf->Cell(70,10, "Eligible for State Govt. Scholarship",0,0);
    $pdf->Cell(0,10, ": ".$scholarship,0,1);
    $pdf->SetFont('Arial','BU',12);
    $pdf->Cell(0,10, "PARENT / GAURDIAN ADDRESS:",0,1);
    $pdf->SetFont('Arial','',12);
    $pdf->Cell(0,8, "S/D/C/o Sri. ".$fname,0,1);
    $pdf->Cell(0,8, $dno.", ".$street,0,1);
    $pdf->Cell(0,8, $village,0,1);
    $pdf->Cell(0,8, $district,0,1);
    $pdf->Cell(0,8, $state." - ".$pincode,0,1);
    $pdf->Cell(40,8, "Parent Mobile No.",0,0);
    $pdf->Cell(80,8, ": ".$pmobile,0,0);
    $pdf->Cell(40,8, "Student Mobile No",0,0);
    $pdf->Cell(0,8, ": ".$smobile,0,1);
    $pdf->SetFont('Arial','BU',12);
    $pdf->Cell(0,10, "AADHAR DETAILS:",0,1);
    $pdf->SetFont('Arial','',12);
    $pdf->Cell(40,8, "Student Aadhar No.",0,0);
    $pdf->Cell(0,8, ": ".$saadhaar,0,1);
    $pdf->Cell(40,8, "Father Aadhar No.",0,0);
    $pdf->Cell(0,8, ": ".$faadhaar,0,1);
    $pdf->Cell(40,8, "Mother Aadhar No.",0,0);
    $pdf->Cell(0,8, ": ".$maadhaar,0,1);
    $pdf->SetFont('Arial','BU',12);
    $pdf->Cell(0,10, "REFERENCE DETAILS:",0,1);
    $pdf->SetFont('Arial','',12);
    $pdf->Cell(40,8, "Referer Name",0,0);
    $tempFontSize = 12;
    while($pdf->GetStringWidth($suggest)>140){
        $pdf->SetFontSize($tempFontSize -= 0.1);
    }
    $pdf->Cell(0,8, ": ".$suggest,0,1);

	//Second Page
	$pdf->AddPage();

    $pdf->SetXY(10, 10);

    $pdf->SetFont('Arial','BU',12);
    $pdf->Cell(0,10, "DETAILS OF EDUCATIONAL QUALIFICATION:",0,1);

    $pdf->SetFont('Arial','B',8);
    $pdf->Cell(30,25, "EDUCATION",1,0,'C');
    $pdf->Cell(90,25, "NAME OF THE INSTITUTE",1,0,'C');
    $pdf->Cell(28,25, "BOARD OF STUDY",1,0,'C');
    $pdf->Cell(12,25, "YOP",1,0,'C');
    $pdf->Cell(0,25, "PERCENTAGE/CGPA",1,1,'C');

    $pdf->SetFont('Arial','',8);
    $pdf->Cell(30,25, "10TH/ EQUIVALENT",1,0,'C');
    $xPos = $pdf->GetX();
    $yPos = $pdf->GetY();
    $cellHeight = 25;
    if($pdf->GetStringWidth($schname) > 90){
        $cellHeight /= 2;
    }
    $pdf->MultiCell(90,$cellHeight, $schname,1,'C');
    $pdf->SetXY($xPos + 90 , $yPos);
    $pdf->Cell(28,25, $sscbos,1,0,'C');
    $pdf->Cell(12,25, $sscyop,1,0,'C');
    $pdf->Cell(0,25, $ssccgpa,1,1,'C');

    $pdf->Cell(30,25, "12TH/ EQUIVALENT",1,0,'C');
    $xPos = $pdf->GetX();
    $yPos = $pdf->GetY();
    $cellHeight = 25;
    if($pdf->GetStringWidth($clgname) > 90){
        $cellHeight /= 2;
    }
    $pdf->MultiCell(90,$cellHeight, $clgname,1,'C');
    $pdf->SetXY($xPos + 90 , $yPos);
    $pdf->Cell(28,25, $hscbos,1,0,'C');
    $pdf->Cell(12,25, $hscyop,1,0,'C');
    $pdf->Cell(0,25, $hsccgpa,1,1,'C');

    $pdf->Cell(0,20, "",0,1);
    $pdf->SetFont('Arial','BU',12);
    $pdf->Cell(0,10, "DECLARATION:",0,1);
    $pdf->SetFont('Arial','',12);
    $pdf->MultiCell(190,10, "I hereby declare that all the particulars stated in this application form are true to the best of knowledge and belief. I have read and understood all provisions of admissions and agree to abide by them. In the event of submission of fraudulent, incorrect or untrue information or distortion of any fact like educational qualification, marks, nationality, etc., I understand that my admission / degree is liable for cancellation. I further understand that my admission is purely provisional subject to the verification of the eligibility conditions. I am also aware of the financial obligation of applying to and studying at this institution and I undertake to pay the tuition and other fees payable to the institution and to abide by all rules and regulations of the institution.",0,'J',FALSE);

    $pdf->Cell(0,30, "",0,1);
    $pdf->Cell(100,7, "Parent's/Guardian's Signature",0,0);
    $pdf->Cell(0,7, "Student's Signature",0,1);

    $cellWidth = 90;
    $tempFontSize = 12;
    while($pdf->GetStringWidth($fname)>$cellWidth || $pdf->GetStringWidth($sname)>$cellWidth){
        $pdf->SetFontSize($tempFontSize -= 0.1);
    }
    $pdf->Cell(100,7, $fname,0,0);
    $pdf->Cell(0,7, $sname,0,1,);

    //Third Page
    $pdf->AddPage();

    $pdf->SetXY(10, 10);
    $pdf->SetFont('Arial','',12);

    $pdf->Cell(0,10, "Date : ".$doj,0,1);

    $pdf->Cell(0,7, "",0,1);
    $pdf->Cell(0,7, "To",0,1);
    $pdf->Cell(0,7, "The Principal",0,1);
    $pdf->Cell(0,7, "GIET Degree College",0,1);
    $pdf->Cell(0,7, "NH-16, Chaitanya Knowledge City",0,1);
    $pdf->Cell(0,7, "RAJAMAHENDRAVARAM - 533296",0,1);

    $pdf->Cell(0,7, "",0,1);
    $pdf->Cell(0,10, "Sir/Madam,",0,1);
    $pdf->MultiCell(190,8, "I, ".$fname." F/o ".$sname." admitted my Son / Daughter in GIET Degree College in ".$course.". I hereby agree to pay the following fees stipulated below.",0,'J',FALSE);

    $pdf->SetFont('Arial','BU',12);
    $pdf->MultiCell(190,10, "FEE DETAILS",0,'C',FALSE);
    $pdf->SetFont('Arial','B',12);
    $pdf->Cell(100,10, "I Year (At the time of Admission)",0,0);
    $pdf->Cell(60,10, ($y)." - ".($y+1),0,0);
    $pdf->Cell(0,10, "Rs. ".$totf."/-",0,1,'R');
    $pdf->SetFont('Arial','',12);
    $pdf->MultiCell(190,7, "(Tuition Fee: Rs. ".$tf." + Admission Fee: Rs. ".$af." + Laboratory Fee : Rs. ".$lf." + Industry Institute Interaction Fee : Rs. ".$iif." + PDP Fee: Rs. ".$pf." - Concession : Rs. ".$concession.")",0,'J',FALSE);

    $pdf->SetFont('Arial','B',12);
    $pdf->MultiCell(190,10, "(RUPEES ".numberTowords("$num")." ONLY)",0,'C',FALSE);

    $pdf->Cell(100,10, "II Year (At the time of reopening the College)",0,0);
    $pdf->Cell(60,10, ($y+1)." - ".($y+2),0,0);
    $pdf->Cell(0,10, "Rs. ".$totf."/-",0,1,'R');
    $pdf->SetFont('Arial','',12);
    $pdf->MultiCell(190,7, "(Tuition Fee: Rs. ".$tf." + Registration Fee: Rs. ".$af." + Laboratory Fee : Rs. ".$lf." + Industry Institute Interaction Fee : Rs. ".$iif." + PDP Fee: Rs. ".$pf." - Concession : Rs. ".$concession.")",0,'J',FALSE);
    $pdf->SetFont('Arial','B',12);
    $pdf->MultiCell(190,10, "(RUPEES ".numberTowords("$num")." ONLY)",0,'C',FALSE);

    $pdf->Cell(100,10, "III Year (At the time of reopening the College)",0,0);
    $pdf->Cell(60,10, ($y+2)." - ".($y+3),0,0);
    $pdf->Cell(0,10, "Rs. ".$totf."/-",0,1,'R');
    $pdf->SetFont('Arial','',12);
    $pdf->MultiCell(190,7, "(Tuition Fee: Rs. ".$tf." + Registration Fee: Rs. ".$af." + Laboratory Fee : Rs. ".$lf." + Industry Institute Interaction Fee : Rs. ".$iif." + PDP Fee: Rs. ".$pf." - Concession : Rs. ".$concession.")",0,'J',FALSE);
    $pdf->SetFont('Arial','B',12);
    $pdf->MultiCell(190,10, "(RUPEES ".numberTowords("$num")." ONLY)",0,'C',FALSE);
    $pdf->SetFont('Arial','',12);
    $pdf->Cell(0,7, "Note:  Transportation Fee / Hostel Charges may be enhanced for the ensuing years. ",0,1);


    $pdf->Cell(0,20, "",0,1);
    $pdf->Cell(100,7, "Student's Signature",0,0);
    $pdf->Cell(0,7, "Parent's/Guardian's Signature",0,1);

    $cellWidth = 90;
    $tempFontSize = 12;
    while($pdf->GetStringWidth($sname)>$cellWidth || $pdf->GetStringWidth($fname)>$cellWidth){
        $pdf->SetFontSize($tempFontSize -= 0.1);
    }
    $pdf->Cell(100,7, $sname,0,0);
    $pdf->Cell(0,7, $fname,0,1);

    //Fourth Page
    $pdf->AddPage();

	$pdf->SetXY(0, 0);
    $pdf->Image('images/header.jpg');

    $pdf->SetXY(10, 50);
    $pdf->SetFont('Arial','BU',14);

    $pdf->MultiCell(190,15, "FEE REIMBURSEMENT DECLARATION FORM",0,'C',FALSE);

    $pdf->SetFont('Arial','',12);
    $pdf->Cell(0,10, "Date : ".$doj,0,1);

    $pdf->Cell(0,7, "",0,1);
    $pdf->Cell(0,7, "To",0,1);
    $pdf->Cell(0,7, "The Principal",0,1);
    $pdf->Cell(0,7, "GIET Degree College",0,1);
    $pdf->Cell(0,7, "NH-16, Chaitanya Knowledge City",0,1);
    $pdf->Cell(0,7, "RAJAMAHENDRAVARAM - 533296",0,1);

    $pdf->Cell(0,6, "",0,1);
    $pdf->Cell(0,10, "Sir/Madam,",0,1);
    $pdf->MultiCell(190,10, "I, ".$sname." S/o (or) D/o Sri. ".$fname.", have been admitted to 1st Year ".$course." in GIET Degree College, Rajamahendravaram for the Academic Year ".($y)." -".($y+1).".",0,'J',FALSE);
    $pdf->Cell(0,6, "",0,1);
    $pdf->MultiCell(190,10, "I am to inform you that I belong to the ".$category." category. As per the guidelines issued by the State Government, I am eligible to get the Fee Reimbursement / Scholarship towards Tuition Fee.",0,'J',FALSE);
    $pdf->Cell(0,6, "",0,1);
    $pdf->MultiCell(190,10, "I, hereby, undertake that if the Reimbursement / Jagananna Vidyadeevena is not sanctioned / released by the State Government for any reason, I will pay the Tuition Fee and other fees. If for any reason, I discontinue my studies, I promise to pay the Tuition & Other fee for the remaining years.",0,'J',FALSE);

    $pdf->Cell(0,20, "",0,1);
    $pdf->Cell(100,7, "Parent's/Guardian's Signature",0,0);
    $pdf->Cell(0,7, "Student's Signature",0,1);

    $cellWidth = 90;
    $tempFontSize = 12;
    while($pdf->GetStringWidth($fname)>$cellWidth || $pdf->GetStringWidth($sname)>$cellWidth){
        $pdf->SetFontSize($tempFontSize -= 0.1);
    }
    $pdf->Cell(100,7, $fname,0,0);
    $pdf->Cell(0,7, $sname,0,1);
    $pdf->SetFont('Arial','',12);
    $pdf->Cell(100,7, "Parent�s Mobile No : ".$pmobile,0,0);
    $pdf->Cell(0,7, "Student�s Mobile No: ".$smobile,0,1);

    //Fifth Page
    $pdf->AddPage();

	$pdf->SetXY(0, 0);
    $pdf->Image('images/header.jpg');

    $pdf->SetXY(10, 50);
    $pdf->SetFont('Arial','BU',14);

    $pdf->MultiCell(190,15, "STUDENT DECLARATION FORM",0,'C',FALSE);

    $pdf->SetFont('Arial','',12);
    $pdf->Cell(0,10, "Date : ".$doj,0,1);

    $pdf->Cell(0,7, "",0,1);
    $pdf->Cell(0,7, "To",0,1);
    $pdf->Cell(0,7, "The Principal",0,1);
    $pdf->Cell(0,7, "GIET Degree College",0,1);
    $pdf->Cell(0,7, "NH-16, Chaitanya Knowledge City",0,1);
    $pdf->Cell(0,7, "RAJAMAHENDRAVARAM",0,1);

    $pdf->Cell(0,6, "",0,1);
    $pdf->Cell(0,10, "Sir/Madam,",0,1);
    $pdf->MultiCell(190,10, "I, ".$sname." S/o (or) D/o Sri. ".$fname.", have been admitted to 1st Year ".$course." in GIET Degree College, Rajamahendravaram for the Academic Year ".($y)." -".($y+1).".",0,'J',FALSE);
    $pdf->Cell(0,6, "",0,1);
    $pdf->MultiCell(190,10, "I shall complete my course in a stipulated time. If I discontinue my study at GIET Degree College, Rajamahendravaram, I promise to pay the full amount of Tuition Fee and Other Fee for the remaining years, failing which, the Institute is at liberty to take suitable action for recovery of the same.",0,'J',FALSE);
    $pdf->Cell(0,6, "",0,1);
    $pdf->Cell(0,10, "Thanking you,",0,1);

    $pdf->Cell(0,20, "",0,1);
    $pdf->Cell(100,7, "Parent's/Guardian's Signature",0,0);
    $pdf->Cell(0,7, "Student's Signature",0,1);

    $cellWidth = 90;
    $tempFontSize = 12;
    while($pdf->GetStringWidth($fname)>$cellWidth || $pdf->GetStringWidth($sname)>$cellWidth){
        $pdf->SetFontSize($tempFontSize -= 0.1);
    }
    $pdf->Cell(100,7, $fname,0,0);
    $pdf->Cell(0,7, $sname,0,1);
    $pdf->SetFont('Arial','',12);
    $pdf->Cell(100,7, "Parent�s Mobile No : ".$pmobile,0,0);
    $pdf->Cell(0,7, "Student�s Mobile No: ".$smobile,0,1);

    //Sixth Page
    $pdf->AddPage();

	$pdf->SetXY(0, 0);
    $pdf->Image('images/header.jpg');

    $pdf->SetXY(10, 50);
    $pdf->SetFont('Arial','BU',14);

    $pdf->MultiCell(190,15, "ANTI RAGGING UNDERTAKING BY THE STUDENT AND PARENT / GUARDIAN",0,'C',FALSE);

    $pdf->SetFont('Arial','',12);
    $pdf->MultiCell(190,6, "I, ".$sname.", am studying 1st Year ".$course." at GIET Degree College, Rajamahendravaram S/o (or) D/o ".$fname." residing at ".$dno.", ".$street.", ".$village.", ".$district.", ".$state." - ".$pincode.".",0,'J',FALSE);
    $pdf->Cell(0,5, "",0,1);
    $pdf->MultiCell(190,6, "Undertake that I am aware of the meaning of �Ragging� as defined by the Supreme Court, that �Ragging is any disorderly conduct, whether by words spoken or written, or by an act which has the effect of teasing, treating or handling a fresher or a junior with rudeness, indulging in rowdy or indiscipline activities which cause or are likely to cause annoyance, hardship or psychological harm or to raise fear or apprehension thereof in a fresher or a junior student and which has the effect of causing or generating a sense of shame or embarrassment, so as to adversely affect the psyche of a fresher or a junior student�.",0,'J',FALSE);
    $pdf->Cell(0,5, "",0,1);
    $pdf->MultiCell(190,6, "I am also aware of the system of punishment in case of ragging other students and that in case I become involved in the act of ragging I am liable for any punishment including :",0,'J',FALSE);
	$pdf->Cell(0,5, "",0,1);
	$pdf->SetFont('Arial','',10);
	$pdf->MultiCell(190,6, "       1. Cancellation of admission
       2. Suspension from attending classes, withholding / withdrawing scholarship / fellowship and other benefits
       3. Debarring from appearing for any test / examination or other evaluation process
       4. Withholding results
       5. Debarring from representing the Institution in any National or International Meet, Tournament, Youth Festival etc.
       6. Suspension, expulsion from the hostel
       7. Rustication from the Institution for periods varying from 1 to 2 academic years
       8. Expulsion from the institution and consequent debarring from admission to any other institution
       9. Fine up to Rs. 50,000/-
       10. Rigorous imprisonment up to three years (by court of Law) etc.,",0,'J',FALSE);
    $pdf->SetFont('Arial','',12);
    $pdf->Cell(0,5, "",0,1);
    $pdf->MultiCell(190,7, "I endorse the undertaking given above and I promise to abide by the same.",0,'J',FALSE);

    $pdf->Cell(0,20, "",0,1);
    $pdf->Cell(100,6, "Parent's/Guardian's Signature",0,0);
    $pdf->Cell(0,6, "Student's Signature",0,1);

    $cellWidth = 90;
    $tempFontSize = 12;
    while($pdf->GetStringWidth($sname)>$cellWidth || $pdf->GetStringWidth($fname)>$cellWidth){
        $pdf->SetFontSize($tempFontSize -= 0.1);
    }
    $pdf->Cell(100,6, $fname,0,0);
    $pdf->Cell(0,6, $sname,0,1);
    $pdf->SetFont('Arial','',12);
    $pdf->Cell(0,6, "Date : ".$doj,0,1);

    //Seventh Page
    $pdf->AddPage();

	$pdf->SetXY(0, 0);
    $pdf->Image('images/header.jpg');

    $pdf->SetXY(10, 50);
    $pdf->SetFont('Arial','BU',14);

    $pdf->MultiCell(190,50, "UNDERTAKING LETTER FROM THE STUDENT",0,'C',FALSE);

    $pdf->SetFont('Arial','',12);
    $pdf->MultiCell(190,10, "I ".$sname.", S/o (or) D/o ".$fname." studying 1st Year 1st Semester in GIET Degree College, Rajamahendravaram hereby declare that I will follow the rules and regulations of the college. I shall never participate or support any ragging activities involved by any other students of the college. This letter is submitted knowing the full implications and the consequences.",0,'J',FALSE);

    $pdf->Cell(0,10, "",0,1);
    $pdf->Cell(0,20, "",0,1);
    $pdf->Cell(100,7, "Parent's/Guardian's Signature",0,0);
    $pdf->Cell(0,7, "Student's Signature",0,1);

    $cellWidth = 90;
    $tempFontSize = 12;
    while($pdf->GetStringWidth($sname)>$cellWidth || $pdf->GetStringWidth($fname)>$cellWidth){
        $pdf->SetFontSize($tempFontSize -= 0.1);
    }
    $pdf->Cell(100,7, $fname,0,0);
    $pdf->Cell(0,7, $sname,0,1);
    $pdf->SetFont('Arial','',12);
    $pdf->Cell(0,7, "Date : ".$doj,0,1);

    //Eighth Page
    $pdf->AddPage();

	$pdf->SetXY(0, 0);
    $pdf->Image('images/header.jpg');
    $pdf->SetFont('Arial','BI',10);
    $pdf->SetXY(10, 10);
    $pdf->Cell(150,10,"PIN: ".$admno,0,0);
    $pdf->Cell(0,10,"OFFICE COPY",0,1,'R');

    $pdf->SetXY(10, 50);
    $pdf->SetFont('Arial','',10);

    $pdf->Cell(35,5, "Name of the Course",0,0);
    $pdf->Cell(100,5, ": ".$course,0,0);
    $pdf->Cell(30,5, "Date",0,0);
    $pdf->Cell(0,5, ": ".$doj,0,1);
    $pdf->Cell(35,5, "Student Name",0,0);
    $cellWidth = 90;
    $tempFontSize = 10;
    while($pdf->GetStringWidth($sname)>$cellWidth){
        $pdf->SetFontSize($tempFontSize -= 0.1);
    }
    $pdf->Cell(100,5, ": ".$sname,0,0);
    $pdf->SetFont('Arial','',10);
    $pdf->Cell(30,5, "Student Mobile No",0,0);
    $pdf->Cell(0,5, ": ".$smobile,0,1);
    $pdf->Cell(35,5, "Father Name" ,0,0);
    $cellWidth = 90;
    $tempFontSize = 10;
    while($pdf->GetStringWidth($fname)>$cellWidth){
        $pdf->SetFontSize($tempFontSize -= 0.1);
    }
    $pdf->Cell(100,5, ": ".$fname,0,0);
    $pdf->SetFont('Arial','',10);
    $pdf->Cell(30,5, "Parent Mobile No",0,0);
    $pdf->Cell(0,5, ": ".$pmobile,0,1);

    $pdf->SetFont('Arial','B',10);
    $pdf->Cell(95,7, "ORIGINAL CERTIFICATES SUBMITTED",1,0,'C');
    $pdf->Cell(0,7, "XEROX CERTIFICATES SUBMITTED",1,1,'C');
    $pdf->SetFont('Arial','',10);
    $xPos = $pdf->GetX();
    $yPos = $pdf->GetY();
    $cellHeightOrg = 40;
    if($pdf->GetStringWidth($originals) > 285){
        $cellHeightOrg /= 1.332;
    }
    if($pdf->GetStringWidth($originals) > 190){
        $cellHeightOrg /= 1.5;
    }
    if($pdf->GetStringWidth($originals) > 95){
        $cellHeightOrg /= 2;
    }
    $pdf->MultiCell(95,$cellHeightOrg, $originals,1);

    $cellHeightXer = 40;
    if($pdf->GetStringWidth($xerox) > 285){
        $cellHeightXer /= 1.332;
    }
    if($pdf->GetStringWidth($xerox) > 190){
        $cellHeightXer /= 1.5;
    }
    if($pdf->GetStringWidth($xerox) > 95){
        $cellHeightXer /= 2;
    }

    $pdf->SetXY($xPos + 95 , $yPos);
    $pdf->MultiCell(95,$cellHeightXer, $xerox,1);

    $pdf->Cell(0,12, "",0,1);
    $pdf->Cell(110,5, "Parent's/Student's Signature",0,0);
    $pdf->Cell(0,5, "Staff Signature",0,1,'C');

    $cellWidth = 90;
    $tempFontSize = 12;
    while($pdf->GetStringWidth($sname)>$cellWidth){
        $pdf->SetFontSize($tempFontSize -= 0.1);
    }
    $pdf->Cell(110,5, $sname,0,0);
    $pdf->Cell(0,5, "Name :",0,1);
    $pdf->Cell(0,5, "",0,1);
    $pdf->Cell(0,5, "",1,1);

    $pdf->SetXY(0, 140);
    $pdf->Image('images/header.jpg');
    $pdf->SetFont('Arial','BI',10);
    $pdf->SetXY(10, 150);
    $pdf->Cell(150,10,"PIN: ".$admno,0,0);
    $pdf->Cell(0,10,"CANDIDATE COPY",0,1,'R');


    $pdf->SetXY(10, 190);
    $pdf->SetFont('Arial','',10);

    $pdf->Cell(35,5, "Name of the Course",0,0);
    $pdf->Cell(100,5, ": ".$course,0,0);
    $pdf->Cell(30,5, "Date",0,0);
    $pdf->Cell(0,5, ": ".$doj,0,1);
    $pdf->Cell(35,5, "Student Name",0,0);
    $cellWidth = 90;
    $tempFontSize = 10;
    while($pdf->GetStringWidth($sname)>$cellWidth){
        $pdf->SetFontSize($tempFontSize -= 0.1);
    }
    $pdf->Cell(100,5, ": ".$sname,0,0);
    $pdf->SetFont('Arial','',10);
    $pdf->Cell(30,5, "Student Mobile No",0,0);
    $pdf->Cell(0,5, ": ".$smobile,0,1);
    $pdf->Cell(35,5, "Father Name" ,0,0);
    $cellWidth = 90;
    $tempFontSize = 10;
    while($pdf->GetStringWidth($fname)>$cellWidth){
        $pdf->SetFontSize($tempFontSize -= 0.1);
    }
    $pdf->Cell(100,5, ": ".$fname,0,0);
    $pdf->SetFont('Arial','',10);
    $pdf->Cell(30,5, "Parent Mobile No",0,0);
    $pdf->Cell(0,5, ": ".$pmobile,0,1);

    $pdf->SetFont('Arial','B',10);
    $pdf->Cell(95,7, "ORIGINAL CERTIFICATES SUBMITTED",1,0,'C');
    $pdf->Cell(0,7, "XEROX CERTIFICATES SUBMITTED",1,1,'C');
    $pdf->SetFont('Arial','',10);
    $xPos = $pdf->GetX();
    $yPos = $pdf->GetY();
    $pdf->MultiCell(95,$cellHeightOrg, $originals,1);
    $pdf->SetXY($xPos + 95 , $yPos);
    $pdf->MultiCell(95,$cellHeightXer, $xerox,1);

    $pdf->Cell(0,12, "",0,1);
    $pdf->Cell(110,5, "Parent's/Student's Signature",0,0);
    $pdf->Cell(0,5, "Staff Signature",0,1,'C');

    $cellWidth = 90;
    $tempFontSize = 12;
    while($pdf->GetStringWidth($sname)>$cellWidth){
        $pdf->SetFontSize($tempFontSize -= 0.1);
    }
    $pdf->Cell(110,5, $sname,0,0);
    $pdf->Cell(0,5, "Name :",0,1);

	$pdf->Output();
}
?>
